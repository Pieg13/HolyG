<body>
    <?php require APP_DIR . '/views/head_view.php'; ?>
    <main>
    <h1>404 - Page Not Found</h1>
    <p>The page you're looking for doesn't exist. <a href="index.php">Return to Home</a></p>
</body>