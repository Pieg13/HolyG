<?php require APP_DIR . '/views/head_view.php'; ?>
<?php require APP_DIR . '/views/header_view.php'; ?>

<?php require VIEW_DIR . '/recipes_view.php';?>
<?php require VIEW_DIR . '/quote_view.php'; ?>
<?php require VIEW_DIR . '/about_view.php'; ?>


<?php require APP_DIR . '/views/footer_view.php'; ?>