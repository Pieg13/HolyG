</main>
<footer id="main-footer">
    <ul id="footer-nav">
        <li><a href="home">HOME</a></li>
        <li><a href="recipes">RECIPES</a></li>
        <li><a href="about">ABOUT</a></li>
        <li><a href="contact">CONTACT</a></li>
    </ul>
    <p>&copy; webpro | Read our <a href="privacy" target="blank">privacy policy</a></p>
</footer>
</body>
</html>

<?php
ob_end_flush();
?>