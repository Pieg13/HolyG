<div class="quote-container container">
    <h2>Get a random food quote !</h2>
    <div id="quoteDisplay" class="quote-content"></div>
    <button id="randomQuoteBtn" class="button">Get Random Food Quote</button>
</div>

<script type="module" src="public/js/quote_request.js"></script>