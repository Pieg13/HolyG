<?php require APP_DIR . '/views/head_view.php'; ?>
<?php require APP_DIR . '/views/header_view.php'; ?>

<main>
<h1>ERROR !</h1>
<p>
    <?= $error;?>
</p>

<?php require APP_DIR . '/views/footer_view.php'; ?>