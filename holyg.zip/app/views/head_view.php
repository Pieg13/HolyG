<?php
include_once 'app/utils/minify.php';
ob_start('minify_output');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link rel="shortcut icon" href="public/images/avocado.ico" type="image/x-icon">
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>