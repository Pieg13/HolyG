<?php
$title = "Page Not Found | HolyG";
require APP_DIR . '/views/head_view.php';
require APP_DIR . '/views/404_view.php';
?>