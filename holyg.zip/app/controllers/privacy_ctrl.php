<?php  $title = "Privacy policy | HolyG" ?>

<?php require APP_DIR . '/views/head_view.php'; ?>
<?php require APP_DIR . '/views/privacy_view.php'; ?>