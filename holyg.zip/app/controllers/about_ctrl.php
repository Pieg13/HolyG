<?php

$title = "About | HolyG";

require APP_DIR . '/views/head_view.php';
require APP_DIR . '/views/header_view.php';
require APP_DIR . '/views/about_view.php';
require APP_DIR . '/views/footer_view.php';
?>